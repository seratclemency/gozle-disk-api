from .gozle_disk import gozle_disk

__all__ = ['gozle_disk']